﻿using Compliance.DataAccess;
using Compliance.DataObject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ComplianceService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "VendorService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select VendorService.svc or VendorService.svc.cs at the Solution Explorer and start debugging.
    public class VendorService : IVendorService
    {
     

        public int insertVendor(VendorMaster vendor)
        {
            int VendorID = 0;
            bool insertResult = false;
            try
            {
                VendorHelper vendorhelper = new VendorHelper();
                VendorID = vendorhelper.insertupdateVendor(vendor, 'I');
                if (VendorID>0)
                {
                    insertResult = true;
                }
            }
            catch
            {
                throw;
            }
            return VendorID;
        }

        public int updateVendor(VendorMaster vendor)
        {
            int VendorID = 0;
            bool updateResult = false;
            try
            {
                VendorHelper vendorhelper = new VendorHelper();
                VendorID = vendorhelper.insertupdateVendor(vendor, 'U');
                if (VendorID > 0)
                {
                    updateResult = true;
                }
            }
            catch
            {
                throw;
            }
            return VendorID;
        }

        public bool insertVendorForBranch(int[] VendorID, int OrgCompanyID,DateTime StartDate, Nullable<DateTime> EndDate, bool IsActive)
        {
            bool insertResult = false;
            try
            {
                VendorHelper vendorhelper = new VendorHelper();
                foreach (var item in VendorID)
                {
                    insertResult =Convert.ToBoolean( vendorhelper.insertVendorForBranch(item, OrgCompanyID, 'I',StartDate,EndDate,IsActive));
                }
            }
            catch
            {
                throw;
            }
            return insertResult;
        }

        public string DeactivateVendorForCompany(int VendorID)
        {
            string vendor = "";
            VendorHelper vendorHelper = new VendorHelper();
            vendor=Convert.ToString( vendorHelper.DeactivateVendorForCompany(VendorID));
            if(vendor != null)
            {
                return vendor;
            }
            else
            {
                return "Not deactivated";
            }
        }
        public string ActivateVendorForCompany(int VendorID)
        {
            string vendor = "";
            VendorHelper vendorHelper = new VendorHelper();
            vendor = Convert.ToString(vendorHelper.ActivateVendorForCompany(VendorID));
            if (vendor != null)
            {
                return vendor;
            }
            else
            {
                return "Not activated";
            }
        }
        public string DeactivateVendorForBranch(int VendorBranchID)
        {
            string vendor = "";
            VendorHelper vendorHelper = new VendorHelper();
            vendor = Convert.ToString(vendorHelper.DeactivateVendorForBranch(VendorBranchID));
            if (vendor != null)
            {
                return vendor;
            }
            else
            {
                return "Not deactivated";
            }
        }
        public string ActivateVendorForBranch(int BranchID)
        {
            string vendor = "";
            VendorHelper vendorHelper = new VendorHelper();
            vendor = Convert.ToString(vendorHelper.ActivateVendorForBranch(BranchID));
            if (vendor != null)
            {
                return vendor;
            }
            else
            {
                return "Not deactivated";
            }
        }

    }
}
